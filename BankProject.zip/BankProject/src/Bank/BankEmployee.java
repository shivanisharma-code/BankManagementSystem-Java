package Bank;
public class BankEmployee extends Person {
    private int employeeId;
    private String designation;
    private Department department;
    private int salary;
    private AuthenticationDetails authDetails;
    public BankEmployee(String name, int age, String adhaar, int employeeId, String designation,
                        int salary, Department department, AuthenticationDetails authDetails) {
        super(name, age, adhaar);
        this.employeeId = employeeId;
        this.designation = designation;
        this.salary = salary;
        this.department = department;
        this.authDetails = authDetails;
    }
    public boolean login(String username, String password) {
    	return authDetails != null && authDetails.validate(username, password);
    }
    public int getEmployeeId() {
        return employeeId;
    }
    public String getDesignation() {
        return designation;
    }
    public Department getDepartment() {
        return department;
    }
    public int getSalary() {
        return salary;
    }
    public AuthenticationDetails getAuthDetails() {
        return authDetails;
    }
    public void showEmployeeInfo() {
        System.out.println("Employee ID: " + employeeId);
        System.out.println("Name: " + getName());
        System.out.println("Age: " + getAge());
        System.out.println("Adhaar Number: " + getAdhaarNumber());
        System.out.println("Designation: " + designation);
        System.out.println("Department: " + department);
        System.out.println("Salary: ₹" + salary);
    }

}

