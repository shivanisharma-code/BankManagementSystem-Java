package Bank;
import java.util.Scanner;
public class AuthTest {
    public static void main(String[] args) {
        AuthenticationDetails auth = new AuthenticationDetails("shivani", "pass123");
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter username: ");
        String inputUser = sc.nextLine();
        System.out.print("Enter password: ");
        String inputPass = sc.nextLine();
        if (auth.validate(inputUser, inputPass)) {
            System.out.println("Login successful.");
        } else {
            System.out.println("Invalid credentials.");
        }
        sc.close();
    }
}
