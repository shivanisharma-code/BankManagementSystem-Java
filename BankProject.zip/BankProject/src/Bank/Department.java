package Bank;

public class Department {
    private String name;
    private static int numberOfDepartments = 0;
    private int numOfEmployees;
    private int budget;
    public Department(String name, int numOfEmployees, int budget) {
        this.name = name;
        this.numOfEmployees = numOfEmployees;
        this.budget = budget;
        numberOfDepartments++;
    }
    public String getName() {
        return name;
    }
    public int getNumOfEmployees() {
        return numOfEmployees;
    }
    public int getBudget() {
        return budget;
    }
    public static int getNumberOfDepartments() {
        return numberOfDepartments;
    }
    public void showDepartmentInfo() {
        System.out.println("Department: " + name);
        System.out.println("Employees: " + numOfEmployees);
        System.out.println("Budget: ₹" + budget);
    }
}
