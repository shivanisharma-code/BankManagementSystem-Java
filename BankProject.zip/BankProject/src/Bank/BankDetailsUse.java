package Bank;

public class BankDetailsUse {
    public static void main(String args[]) {
        BankDetails b1 = new BankDetails("shivani", "Sbi0020");
        BankDetails b2 = new BankDetails("sharma", "Sbi0020");
        User u1 = new User(b1, "shivani", 18, "23456");
        User u2 = new User(b2, "sharma", 18, "23457");
        System.out.println("=== Initial Account Info ===");
        u1.getBankDetails().showAccountInfo();
        System.out.println();
        u2.getBankDetails().showAccountInfo();
        System.out.println("\n=== Initial Balances ===");
        System.out.println("u1: ₹" + b1.getTotalBalance());
        System.out.println("u2: ₹" + b2.getTotalBalance());
        DepositService.deposit(u1, 1000000);
        DepositService.deposit(u2, 200000);

        System.out.println("\n=== After Deposit ===");
        System.out.println("u1: ₹" + b1.getTotalBalance());
        System.out.println("u2: ₹" + b2.getTotalBalance());
    }
}
