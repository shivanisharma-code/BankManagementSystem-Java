package Bank;

import java.time.LocalDateTime;

public class DepositService {
    public static void deposit(User user, double amount) {
        if (user == null || amount <= 0) {
            System.out.println("Invalid deposit request.");
            return;
        }

        user.getBankDetails().addMoney(amount);
        System.out.println("₹" + amount + " deposited into account " + user.getUserAccountNumber());
        System.out.println("Deposited at: " + LocalDateTime.now());
    }
}
