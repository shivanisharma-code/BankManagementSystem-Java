package Bank;

public class User extends Person {
	private BankDetails bankDetails;

    public User(BankDetails bankDetails, String name, int age, String adhaarNumber) {
        super(name, age, adhaarNumber);
        this.bankDetails = bankDetails;
    }
    public BankDetails getBankDetails() {
        return bankDetails;
    }
    public void setBankDetails(BankDetails b1) {
        this.bankDetails = b1;
    }
    public double getUserBalance() {
        return bankDetails.getTotalBalance();
    }
    public int getUserAccountNumber() {
        return bankDetails.getAccountNumber();
    }
    public String getBankName() {
        return BankDetails.BANK_NAME;
    }
    public void showUserInfo() {
        System.out.println("User Name: " + getName());
        System.out.println("Age: " + getAge());
        System.out.println("Adhaar Number: " + getAdhaarNumber());
        System.out.println("Bank Account Number: " + bankDetails.getAccountNumber());
        System.out.println("Bank Balance: ₹" + bankDetails.getTotalBalance());
    }
}
