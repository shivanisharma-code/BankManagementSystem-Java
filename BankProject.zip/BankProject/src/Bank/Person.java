package Bank;

public class Person {
    private String name;
    private String adhaarNumber;
    private int age;

    public Person(String name, int age, String adhaarNumber) {
        this.name = name;
        this.age = age;
        this.adhaarNumber = adhaarNumber;
    }
    public String getName() {
        return name;
    }
    public String getAdhaarNumber() {
        return adhaarNumber;
    }
    public int getAge() {
        return age;
    }
    public void setName(String name) {
        this.name = name;
    }
    public void setAge(int age) {
        this.age = age;
    }
    public void setAdhaarNumber(String adhaarNumber) {
        this.adhaarNumber = adhaarNumber;
    }
}

