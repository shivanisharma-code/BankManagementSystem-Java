package Bank;

public class BankDetails {
    private String name;
    private static int numOfAccounts;
    private int accountNumber;
    private String ifsc;
    public static final String BANK_NAME = "SBI";
    private double balance;
    public BankDetails(String name, String ifsc) {
        this.name = name;
        this.ifsc = ifsc;
        this.balance = 0.0;
        numOfAccounts++;
        this.accountNumber = numOfAccounts;
    }
    public BankDetails(String name, String ifsc, double submitAmount) {
        this.name = name;
        this.ifsc = ifsc;
        this.balance = submitAmount > 0 ? submitAmount : 0.0;
        numOfAccounts++;
        this.accountNumber = numOfAccounts;
    }
    public int getAccountNumber() {
        return this.accountNumber;
    }
    public double getTotalBalance() {
        return this.balance;
    }
    public void addMoney(double amount) {
        if (amount <= 0) {
            System.out.println("Invalid deposit amount.");
            return;
        }
        this.balance += amount;
    }
    public void withDrawMoney(double amount) {
        if (amount <= 0) {
            System.out.println("Invalid withdrawal amount.");
        } else if (amount > this.balance) {
            System.out.println("Insufficient balance.");
        } else {
            this.balance -= amount;
        }
    }
    public String getIfsc() {
        return ifsc;
    }
    public void showAccountInfo() {
        System.out.println("Account Number: " + accountNumber);
        System.out.println("Name: " + name);
        System.out.println("Balance: ₹" + balance);
        System.out.println("IFSC: " + ifsc);
        System.out.println("Bank: " + BANK_NAME);
    }
}
